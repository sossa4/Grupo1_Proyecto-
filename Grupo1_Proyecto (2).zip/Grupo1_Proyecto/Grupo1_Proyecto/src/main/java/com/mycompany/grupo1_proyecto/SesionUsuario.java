/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author Deliany Brenes
 */
import java.util.Date;

public class SesionUsuario {
    private Usuario usuario;
    private Date inicioSesion;
    private Date expiracionSesion;

    public SesionUsuario(Usuario usuario, Date inicioSesion, Date expiracionSesion) {
        this.usuario = usuario;
        this.inicioSesion = inicioSesion;
        this.expiracionSesion = expiracionSesion;
    }

    public void cerrarSesion() {
        this.usuario = null;
        this.inicioSesion = null;
        this.expiracionSesion = null;
    }

    // Getters y Setters

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getInicioSesion() {
        return inicioSesion;
    }

    public Date getExpiracionSesion() {
        return expiracionSesion;
    }
}
