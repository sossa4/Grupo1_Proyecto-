/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author brene
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterWindow extends JFrame {

    private JTextField nombreField;
    private JTextField apellidoField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton registerButton;

    public RegisterWindow() {
        // Configuración de la ventana
        setTitle("Register");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2));

        // Componentes de la interfaz
        nombreField = new JTextField(20);
        apellidoField = new JTextField(20);
        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        registerButton = new JButton("Register");

        // Añadir componentes
        add(new JLabel("Nombre:"));
        add(nombreField);
        add(new JLabel("Apellido:"));
        add(apellidoField);
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(registerButton);

        // Eventos de botones
        registerButton.addActionListener(new RegisterButtonListener());
    }

    private class RegisterButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Obtener datos del formulario de registro
            String nombre = nombreField.getText();
            String apellido = apellidoField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Registrar el usuario
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            boolean success = usuarioDAO.registrarUsuario(nombre, apellido, email, password);

            if (success) {
                JOptionPane.showMessageDialog(null, "User registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                // Limpiar campos
                nombreField.setText("");
                apellidoField.setText("");
                emailField.setText("");
                passwordField.setText("");
                
                // Cambiar a la ventana de login
                switchToLogin();
            } else {
                JOptionPane.showMessageDialog(null, "Registration failed. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void switchToLogin() {
        // Crear una nueva instancia de LoginPageWidget y mostrarla
        LoginPageWidget loginPage = new LoginPageWidget();
        loginPage.setVisible(true);
        
        // Cerrar la ventana de registro
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new RegisterWindow().setVisible(true);
        });
    }
}