/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author Deliany Brenes
 */
import java.util.List;

public class Rutina {
    private int id;
    private String nombre;
    private List<Ejercicio> ejercicios;

    // Constructor
    public Rutina(int id, String nombre, List<Ejercicio> ejercicios) {
        this.id = id;
        this.nombre = nombre;
        this.ejercicios = ejercicios;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    public void setEjercicios(List<Ejercicio> ejercicios) {
        this.ejercicios = ejercicios;
    }
}