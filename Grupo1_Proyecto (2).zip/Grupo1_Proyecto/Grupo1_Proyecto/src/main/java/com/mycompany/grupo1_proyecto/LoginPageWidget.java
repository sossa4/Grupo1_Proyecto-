/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author sossa
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPageWidget extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private UsuarioDAO usuarioDAO;

    public LoginPageWidget() {
        // Configuración de la ventana
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2)); // Ajusta el número de filas a 4

        // Inicialización de UsuarioDAO
        usuarioDAO = new UsuarioDAO();

        // Componentes de la interfaz
        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");
        registerButton = new JButton("Register"); // Inicialización del botón de registro

        // Añadir componentes
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(loginButton);
        add(registerButton); // Añadir el botón de registro

        // Eventos de botones
        loginButton.addActionListener(new LoginButtonListener());
        registerButton.addActionListener(new RegisterButtonListener()); // Asignar acción al botón de registro
    }

    private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Obtener datos del formulario de inicio de sesión
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Iniciar sesión
            Usuario usuario = usuarioDAO.iniciarSesion(email, password);

            if (usuario != null) {
                JOptionPane.showMessageDialog(null, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                // Aquí se pasa el usuario al MainPageWidget
                MainPageWidget mainPage = new MainPageWidget(usuario); // Usar el constructor con Usuario
                mainPage.setVisible(true);
                dispose(); // Cierra la ventana de login
            } else {
                JOptionPane.showMessageDialog(null, "Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class RegisterButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Abrir la ventana de registro
            new RegisterWindow().setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginPageWidget().setVisible(true);
        });
    }
}