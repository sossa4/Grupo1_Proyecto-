/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author brene
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EjercicioDAO {
    private Connection conexion;

    public EjercicioDAO() {
        try {
            // Ajusta la URL, usuario y contraseña a tu configuración de base de datos
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/dtb_gym", "usuario", "contraseña");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para obtener todos los ejercicios
    public List<Ejercicio> obtenerEjercicios() {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String query = "SELECT * FROM ejercicios";

        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("ejercicio_id");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                String videoUrl = rs.getString("video_url");
                String imagenUrl = rs.getString("imagen_url");
                int repeticiones = rs.getInt("repeticiones");
                int duracion = rs.getInt("duracion");
                Ejercicio ejercicio = new Ejercicio(id, nombre, descripcion, videoUrl, imagenUrl, repeticiones, duracion);
                ejercicios.add(ejercicio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ejercicios;
    }
}