/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.grupo1_proyecto;

/**
 *
 * @author Deliany Brenes
 */

public class Grupo1_Proyecto {
    public static void main(String[] args) {
        // Inicia la aplicación
        LoginPageWidget loginPage = new LoginPageWidget();
        loginPage.setVisible(true);
    }
}