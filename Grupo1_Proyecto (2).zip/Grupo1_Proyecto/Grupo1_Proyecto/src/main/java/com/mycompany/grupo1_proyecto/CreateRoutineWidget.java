/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author brene
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CreateRoutineWidget extends JFrame {
    private JTextField txtNombreRutina;
    private JComboBox<String> cmbDia;
    private JComboBox<String> cmbCategorias;
    private JComboBox<String> cmbEjercicios;
    private DefaultListModel<String> exerciseListModel;
    private JList<String> exerciseList;
    private JButton btnAddExercise;
    private JButton btnSaveRoutine;
    
    private Map<String, Integer> addedExerciseIds = new HashMap<>();
    private Map<String, Integer> exerciseIdsMap = new HashMap<>();
    private Usuario usuario;  // Agregado para almacenar el usuario

    // Constructor por defecto
    public CreateRoutineWidget() {
        this(null);  // Llama al constructor con Usuario como argumento
    }

    // Constructor que acepta Usuario
    public CreateRoutineWidget(Usuario usuario) {
        this.usuario = usuario;  // Asigna el usuario pasado como argumento

        setTitle("Crear Rutina");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nombre de la Rutina:"), gbc);

        txtNombreRutina = new JTextField();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(txtNombreRutina, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Día de la Semana:"), gbc);

        cmbDia = new JComboBox<>(new String[]{"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"});
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(cmbDia, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Categoría:"), gbc);

        cmbCategorias = new JComboBox<>();
        loadCategories();
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(cmbCategorias, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Ejercicios:"), gbc);

        cmbEjercicios = new JComboBox<>();
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(cmbEjercicios, gbc);

        btnAddExercise = new JButton("Añadir Ejercicio");
        gbc.gridx = 2;
        gbc.gridy = 3;
        panel.add(btnAddExercise, gbc);

        exerciseListModel = new DefaultListModel<>();
        exerciseList = new JList<>(exerciseListModel);
        JScrollPane scrollPane = new JScrollPane(exerciseList);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        panel.add(scrollPane, gbc);

        btnSaveRoutine = new JButton("Guardar Rutina");
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 3;
        panel.add(btnSaveRoutine, gbc);

        add(panel);

        cmbCategorias.addActionListener(e -> loadExercises());

        btnAddExercise.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedExercise = (String) cmbEjercicios.getSelectedItem();
                if (selectedExercise != null && !addedExerciseIds.containsKey(selectedExercise)) {
                    Integer exerciseId = exerciseIdsMap.get(selectedExercise);
                    if (exerciseId != null) {
                        exerciseListModel.addElement(selectedExercise);
                        addedExerciseIds.put(selectedExercise, exerciseId);
                    }
                }
            }
        });

        btnSaveRoutine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveRoutine();
            }
        });
    }

    private void loadCategories() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT nombre FROM categorias";
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery(query)) {

                cmbCategorias.removeAllItems();
                while (rs.next()) {
                    cmbCategorias.addItem(rs.getString("nombre"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadExercises() {
        String selectedCategory = (String) cmbCategorias.getSelectedItem();
        if (selectedCategory != null) {
            try (Connection connection = DatabaseConnection.getConnection()) {
                // Ajusta la consulta SQL si el nombre del campo o la tabla es diferente
                String query = "SELECT nombre, ejercicio_id FROM ejercicios WHERE categoria_id = (SELECT categoria_id FROM categorias WHERE nombre = ?)";
                try (PreparedStatement pstmt = connection.prepareStatement(query)) {
                    pstmt.setString(1, selectedCategory);
                    try (ResultSet rs = pstmt.executeQuery()) {

                        cmbEjercicios.removeAllItems();
                        exerciseIdsMap.clear();
                        while (rs.next()) {
                            String exerciseName = rs.getString("nombre");
                            Integer exerciseId = rs.getInt("ejercicio_id");
                            cmbEjercicios.addItem(exerciseName);
                            exerciseIdsMap.put(exerciseName, exerciseId);
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveRoutine() {
        String nombreRutina = txtNombreRutina.getText();
        String diaSemana = (String) cmbDia.getSelectedItem();

        if (nombreRutina.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre de la rutina no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener el ID del usuario desde el objeto Usuario
        int usuarioId = usuario != null ? usuario.getId() : -1;

        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO rutinas (nombre, usuario_id) VALUES (?, ?)";
            try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, nombreRutina);
                pstmt.setInt(2, usuarioId); // Asigna el ID del usuario
                pstmt.executeUpdate();

                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int rutinaId = generatedKeys.getInt(1);

                        query = "INSERT INTO ejercicios_rutinas (rutina_id, ejercicio_id, dia_semana) VALUES (?, ?, ?)";
                        try (PreparedStatement pstmtExercises = connection.prepareStatement(query)) {
                            for (Integer exerciseId : addedExerciseIds.values()) {
                                pstmtExercises.setInt(1, rutinaId);
                                pstmtExercises.setInt(2, exerciseId);
                                pstmtExercises.setString(3, diaSemana);
                                pstmtExercises.addBatch();
                            }
                            pstmtExercises.executeBatch();
                        }
                        JOptionPane.showMessageDialog(this, "La rutina se ha guardado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        dispose(); // Cerrar la ventana
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar la rutina: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            dispose(); // Cerrar la ventana
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CreateRoutineWidget().setVisible(true));
    }
}