/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author brene
 */

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class MainPageWidget extends JFrame {
    private JList<String> categoriesList;
    private JButton logoutButton;
    private JButton createRoutineButton;
    private Usuario usuario;
    private JTable exercisesTable;
    private JLabel categoryLabel;
    private JTable routinesTable;

    public MainPageWidget(Usuario usuario) {
        this.usuario = usuario;

        // Configuración de la ventana
        setTitle("Main Page - Gym Application");
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(20, 20));

        // Panel de encabezado
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(30, 30, 30));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 100));

        // Etiqueta de bienvenida
        JLabel welcomeLabel = new JLabel("Welcome, " + usuario.getNombre() + "!", JLabel.CENTER);
        welcomeLabel.setForeground(new Color(255, 223, 186));
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 32));
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);

        // Botón de cierre de sesión con icono
        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 18));
        logoutButton.setBackground(new Color(255, 69, 0));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setIcon(new ImageIcon("resources/logout_icon.png"));
        logoutButton.addActionListener(e -> logout());
        headerPanel.add(logoutButton, BorderLayout.EAST);

        // Botón para crear rutina
        createRoutineButton = new JButton("Create Routine");
        createRoutineButton.setFont(new Font("Arial", Font.PLAIN, 18));
        createRoutineButton.setBackground(new Color(0, 150, 136));
        createRoutineButton.setForeground(Color.WHITE);
        createRoutineButton.setFocusPainted(false);
        createRoutineButton.addActionListener(e -> openCreateRoutineWidget());

        // Panel de contenido principal
        JPanel mainContentPanel = new JPanel(new GridLayout(1, 3, 20, 20));
        mainContentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Panel para categorías
        JPanel categoriesPanel = new JPanel(new BorderLayout());
        categoriesPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 150, 136), 3), "Categories", TitledBorder.CENTER, TitledBorder.TOP, new Font("Arial", Font.BOLD, 20), new Color(0, 150, 136)));
        categoriesList = new JList<>();
        categoriesList.setFont(new Font("Arial", Font.PLAIN, 18));
        JScrollPane scrollPane = new JScrollPane(categoriesList);
        categoriesPanel.add(scrollPane, BorderLayout.CENTER);

        // Panel de ejercicios
        JPanel exercisesPanel = new JPanel(new BorderLayout());
        exercisesPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 150, 136), 3), "Exercises", TitledBorder.CENTER, TitledBorder.TOP, new Font("Arial", Font.BOLD, 20), new Color(0, 150, 136)));

        categoryLabel = new JLabel("Select a category to view exercises", JLabel.CENTER);
        categoryLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        exercisesPanel.add(categoryLabel, BorderLayout.NORTH);

        // Tabla para mostrar ejercicios
        exercisesTable = new JTable();
        exercisesTable.setFont(new Font("Arial", Font.PLAIN, 16));
        exercisesTable.setForeground(new Color(50, 50, 50));
        exercisesTable.setBackground(new Color(240, 240, 240));
        JScrollPane tableScrollPane = new JScrollPane(exercisesTable);
        exercisesPanel.add(tableScrollPane, BorderLayout.CENTER);

        // Panel para rutinas
        JPanel routinesPanel = new JPanel(new BorderLayout());
        routinesPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 150, 136), 3), "User Routines", TitledBorder.CENTER, TitledBorder.TOP, new Font("Arial", Font.BOLD, 20), new Color(0, 150, 136)));

        // Tabla para mostrar rutinas
        routinesTable = new JTable();
        routinesTable.setFont(new Font("Arial", Font.PLAIN, 16));
        routinesTable.setForeground(new Color(50, 50, 50));
        routinesTable.setBackground(new Color(240, 240, 240));
        JScrollPane routinesScrollPane = new JScrollPane(routinesTable);
        routinesPanel.add(routinesScrollPane, BorderLayout.CENTER);

        // Añadir paneles al panel principal de contenido
        mainContentPanel.add(categoriesPanel);
        mainContentPanel.add(exercisesPanel);
        mainContentPanel.add(routinesPanel);

        // Agregar componentes a la ventana
        add(headerPanel, BorderLayout.NORTH);
        add(mainContentPanel, BorderLayout.CENTER);
        add(createRoutineButton, BorderLayout.SOUTH);

        // Cargar categorías y rutinas
        loadCategories();
        loadUserRoutines(usuario);

        // Manejar clic en la lista de categorías
        categoriesList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = categoriesList.locationToIndex(e.getPoint());
                    String selectedCategory = categoriesList.getModel().getElementAt(index);
                    categoryLabel.setText("Exercises for: " + selectedCategory);
                    loadExercisesForCategory(selectedCategory);
                }
            }
        });
    }

    private void loadCategories() {
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT nombre FROM categorias")) {

            DefaultListModel<String> listModel = new DefaultListModel<>();
            while (resultSet.next()) {
                listModel.addElement(resultSet.getString("nombre"));
            }
            categoriesList.setModel(listModel);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading categories: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadExercisesForCategory(String categoryName) {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT e.nombre AS 'Exercise', e.descripcion AS 'Description', e.video_url AS 'Video URL' FROM ejercicios e " +
                     "JOIN categorias c ON e.categoria_id = c.categoria_id " +
                     "WHERE c.nombre = ?")) {
            statement.setString(1, categoryName);
            ResultSet resultSet = statement.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Adding column names
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Adding rows
            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = resultSet.getObject(i);
                }
                model.addRow(row);
            }

            exercisesTable.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading exercises: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadUserRoutines(Usuario usuario) {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT r.rutina_id AS 'Routine ID', r.nombre AS 'Routine', GROUP_CONCAT(e.nombre SEPARATOR ', ') AS 'Exercises' " +
                     "FROM rutinas r " +
                     "JOIN ejercicios_rutinas er ON r.rutina_id = er.rutina_id " +
                     "JOIN ejercicios e ON er.ejercicio_id = e.ejercicio_id " +
                     "WHERE r.usuario_id = ? " +
                     "GROUP BY r.rutina_id")) {

            statement.setInt(1, usuario.getId());
            ResultSet resultSet = statement.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Adding column names
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Adding rows
            boolean hasData = false; // Variable para verificar si hay datos
            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = resultSet.getObject(i);
                }
                model.addRow(row);
                hasData = true; // Hay datos, así que esta variable se establece en verdadero
            }

            if (!hasData) {
                System.out.println("No routines found for user ID: " + usuario.getId());
            }

            routinesTable.setModel(model);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading routines: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openCreateRoutineWidget() {
        new CreateRoutineWidget(usuario).setVisible(true);
    }

    private void logout() {
        int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            dispose(); // Close the current window
            // Open login page or main application page
            // Reemplaza LoginPage con la clase adecuada si es necesario
            // new LoginPage().setVisible(true);
            // O redirige a otra página principal si es necesario
        }
    }
}
