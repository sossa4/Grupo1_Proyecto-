/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.grupo1_proyecto;

/**
 *
 * @author brene
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RutinaDAO {

    // Método para obtener una lista de ejercicios desde la base de datos
    public List<Ejercicio> obtenerEjercicios() {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String sql = "SELECT * FROM ejercicios";

        try (Connection conexion = DatabaseConnection.getConnection();
             Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String descripcion = rs.getString("descripcion");
                String videoUrl = rs.getString("video_url");
                String imagenUrl = rs.getString("imagen_url");
                int repeticiones = rs.getInt("repeticiones");
                int duracion = rs.getInt("duracion");

                // Crear instancia de Ejercicio con todos los atributos
                Ejercicio ejercicio = new Ejercicio(id, nombre, descripcion, videoUrl, imagenUrl, repeticiones, duracion);
                ejercicios.add(ejercicio);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ejercicios;
    }

    // Método para agregar una rutina con ejercicios a la base de datos
    public boolean agregarRutinaConEjercicios(String nombreRutina, List<Ejercicio> ejercicios, int usuarioId) {
        String sqlRutina = "INSERT INTO rutinas (nombre, usuario_id) VALUES (?, ?)";
        String sqlEjercicios = "INSERT INTO rutina_ejercicios (rutina_id, ejercicio_id) VALUES (?, ?)";

        try (Connection conexion = DatabaseConnection.getConnection();
             PreparedStatement stmtRutina = conexion.prepareStatement(sqlRutina, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement stmtEjercicios = conexion.prepareStatement(sqlEjercicios)) {

            // Insertar rutina
            stmtRutina.setString(1, nombreRutina);
            stmtRutina.setInt(2, usuarioId);
            int filasAfectadas = stmtRutina.executeUpdate();

            if (filasAfectadas == 0) {
                return false;
            }

            // Obtener el ID de la rutina recién insertada
            try (ResultSet generatedKeys = stmtRutina.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int rutinaId = generatedKeys.getInt(1);

                    // Insertar ejercicios asociados a la rutina
                    for (Ejercicio ejercicio : ejercicios) {
                        stmtEjercicios.setInt(1, rutinaId);
                        stmtEjercicios.setInt(2, ejercicio.getId());
                        stmtEjercicios.addBatch();
                    }
                    stmtEjercicios.executeBatch();
                } else {
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    // Método para obtener las rutinas de un usuario
    public List<Rutina> obtenerRutinasPorUsuario(int usuarioId) {
        List<Rutina> rutinas = new ArrayList<>();
        String sql = "SELECT * FROM rutinas WHERE usuario_id = ?";

        try (Connection conexion = DatabaseConnection.getConnection();
             PreparedStatement stmt = conexion.prepareStatement(sql)) {

            stmt.setInt(1, usuarioId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String nombre = rs.getString("nombre");
                    // Aquí, se asume que Rutina tiene un constructor adecuado y un método para obtener los ejercicios
                    Rutina rutina = new Rutina(id, nombre, obtenerEjerciciosPorRutina(id));
                    rutinas.add(rutina);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rutinas;
    }

    // Método auxiliar para obtener los ejercicios de una rutina
    private List<Ejercicio> obtenerEjerciciosPorRutina(int rutinaId) {
        List<Ejercicio> ejercicios = new ArrayList<>();
        String sql = "SELECT e.* FROM ejercicios e JOIN rutina_ejercicios re ON e.id = re.ejercicio_id WHERE re.rutina_id = ?";

        try (Connection conexion = DatabaseConnection.getConnection();
             PreparedStatement stmt = conexion.prepareStatement(sql)) {

            stmt.setInt(1, rutinaId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String nombre = rs.getString("nombre");
                    String descripcion = rs.getString("descripcion");
                    String videoUrl = rs.getString("video_url");
                    String imagenUrl = rs.getString("imagen_url");
                    int repeticiones = rs.getInt("repeticiones");
                    int duracion = rs.getInt("duracion");

                    ejercicios.add(new Ejercicio(id, nombre, descripcion, videoUrl, imagenUrl, repeticiones, duracion));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ejercicios;
    }
}